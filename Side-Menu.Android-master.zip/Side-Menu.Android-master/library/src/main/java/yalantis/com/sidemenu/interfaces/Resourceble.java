package yalantis.com.sidemenu.interfaces;

/**
 * Created by Konstantin on 12.01.2015.
 */
public interface Resourceble {
    public int getImageRes();

    public String getName();
}
