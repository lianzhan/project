S V G   F O R   A N D R O I D
=============================

DEMO WALLPAPER APP

See NOTICE for license.

Requires the Android SDK and Apache Ant to compile.

Create a file in this directory called 'local.properties' with the single line:

sdk.dir=PATH/TO/ANDROID_SDK

(Replace "PATH/TO/ANDROID_SDK" with the actual path to your Android SDK install).

Plug in a debug-enabled Android device and run the following to build and install the wallpaper:

ant install